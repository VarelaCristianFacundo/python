# Debe ir en la carpeta anterior

from setuptools import setup

setup(
    name = 'segunda_pre-entrega_Cristian_Varela',
    version = '1.0',
    description = 'Segunda pre-entrega del curso de coder python',
    author = 'Cristian Varela',
    author_email = 'cvarelagarcia@gmail.com',
    packages = ['PrimeraEntrega','SegundaEntrega','SegundaEntrega/clases']
)